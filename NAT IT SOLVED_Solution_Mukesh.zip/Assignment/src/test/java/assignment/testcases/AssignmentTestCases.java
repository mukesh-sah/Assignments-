package assignment.testcases;

import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import assignmemt1.pages.HomePage;
import assignmemt1.pages.LoginPage;
import assignment.base.TestBase;
import assignment2.pages.CheckOutPage;
import assignment2.pages.HomePageShopingSite;
import assignment2.pages.LoginPageShopingSite;



public class AssignmentTestCases extends TestBase{
	LoginPage loginPage;
	LoginPageShopingSite loginPageShoping;
	public AssignmentTestCases()
	{
		super();
	}
	
	
	@BeforeMethod
	public void beforeTest() {
	  TestBase.initialize(); 
	  Reporter.log("Chrome is Opened Now");
	}
	
	@Test (priority=1)
	public void facebookCreatePostTest() {
		loginPage=new LoginPage();
		System.out.println("I validate the page title as "+loginPage.validateLoginPageTitle());
		Reporter.log("User navigate to URL and Validate login page Title");
		HomePage homepage=loginPage.login();
		Reporter.log("User Logged in with credentials");
		System.out.println("I validate the page title as "+homepage.validateHomePageTitle());
		Reporter.log("User Validate the home page Title");
		homepage.createPost();
		System.out.println("Post Created on the facebook with Statement"+prop.getProperty("post_contains"));
		Reporter.log("User successfully Created a new post on Facebook");
	}
	
	@Test (priority=2)
	public void ShoppingSiteTest() {
		loginPageShoping = new LoginPageShopingSite();
		System.out.println("I validate the login page title as "+loginPageShoping.validateLoginPageShopingSiteTitle());
		Reporter.log("User navigate to URL and Validate login page Title");
		HomePageShopingSite homePageShoping=loginPageShoping.login();
		Reporter.log("User Logged in with credentials");
		System.out.println("I validate the Home page title as "+homePageShoping.validateHomePageTitle());
		Reporter.log("User Validate the home page Title");
		homePageShoping.addproduct();
		Reporter.log("User added the 3rd highest price product to the cart");
		CheckOutPage checkoutpage=homePageShoping.checkout();
		checkoutpage.CheckOutDetails();
		Reporter.log("User enters the checkout details");
		System.out.println("I validate message after checkout as: "+checkoutpage.validateMessage());
		Reporter.log("User validates the message after checkout");
		
	
	}

  @AfterMethod
  public void afterTest() {
	  driver.quit();
  }

}
