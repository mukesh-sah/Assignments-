package assignment.util;


import assignment.base.TestBase;

public class TestUtil extends TestBase{

	public static String PAGE_LOAD_TIMEOUT=prop.getProperty("PAGE_LOAD_TIMEOUT");
	public static String IMPLICIT_WAIT=prop.getProperty("IMPLICIT_WAIT");
	
	
}
