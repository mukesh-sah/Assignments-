package assignmemt1.pages;



import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import assignment.base.TestBase;

public class LoginPage extends TestBase{
	
	//Page Factory
	
	@FindBy(name="email")
	WebElement username;
	
	@FindBy(name="pass")
	WebElement password;

	@FindBy(xpath="//input[@value='Log In']")
	WebElement login;
	
	public LoginPage()
	{
		PageFactory.initElements(driver, this);	
	}
	public String validateLoginPageTitle()
	{
		driver.get(prop.getProperty("url"));
		Assert.assertEquals(driver.getTitle(),"Facebook – log in or sign up");
		return driver.getTitle();
	}
	public HomePage login()
	{
		username.sendKeys(prop.getProperty("username"));
		password.sendKeys(prop.getProperty("password"));
		login.click();
		return new HomePage();
	}
}
