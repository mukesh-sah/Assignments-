package assignmemt1.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import assignment.base.TestBase;

public class HomePage extends TestBase {
	@FindBy(xpath="//span[contains(text(),'Create Post')]/../..")
	WebElement createpost;
	
	@FindBy(xpath="//a[contains(text(),'Home')]/../../../div")
	WebElement username;

	@FindBy(xpath="//a[contains(text(),'Home')]")
	WebElement home;
	
	@FindBy (xpath = "//button[@data-testid='react-composer-post-button']")
    WebElement postButton;
	
	public HomePage()
	{
		PageFactory.initElements(driver, this);	
	}
	public String validateHomePageTitle()
	{
		Assert.assertEquals(driver.getTitle(),"Facebook");
		return driver.getTitle();
	}
	public void createPost() {
		// TODO Auto-generated method stub
		
		createpost.click();
		Actions actions = new Actions(driver);
		actions.sendKeys(Keys.TAB).perform();
		actions.sendKeys(Keys.TAB).perform();
		actions.sendKeys(prop.getProperty("post_contains")).perform();
		
		
		postButton.click();
		 
	}

}
