package assignment2.pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import assignment.base.TestBase;

public class HomePageShopingSite extends TestBase{
	
	@FindBy(xpath="//select[@class='product_sort_container']")
	WebElement sortby;
	
	@FindBy(id="shopping_cart_container")
	WebElement cart;
	
	@FindBy(xpath="//button[@class='btn_primary btn_inventory']")
	List<WebElement> Items;
	
	@FindBy(xpath="//a[@class='btn_action checkout_button']")
	WebElement checkout;
	
	
	
	
	public HomePageShopingSite()
	{
		PageFactory.initElements(driver, this);	
	}
	public String validateHomePageTitle()
	{
		Assert.assertEquals(driver.getTitle(),"Swag Labs");
		return driver.getTitle();
	}
	
	public void addproduct()
	{
		
		Select drpCountry = new Select(sortby);
		drpCountry.selectByVisibleText("Price (low to high)");
		List<WebElement> allElements =Items;
		//System.out.println(allElements.size());
		int number=1;
		for(WebElement element : allElements){
		    if(number==(allElements.size()-2))
		    {
		    	element.click();
		    }
		    number++;    	
		}
	}
	
	public CheckOutPage checkout()
	{
		cart.click();
		checkout.click();
		return new CheckOutPage();
	}
}
