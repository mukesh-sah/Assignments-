package assignment2.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import assignment.base.TestBase;

public class CheckOutPage extends TestBase{
	
	//Page Factory
	
		@FindBy(id="first-name")
		WebElement firstname;
		
		@FindBy(id="last-name")
		WebElement lastname;

		@FindBy(id="postal-code")
		WebElement zipcode;
		
		@FindBy(xpath="//input[@class='btn_primary cart_button']")
		WebElement continuebutton;
		
		@FindBy(xpath="//a[@class='btn_action cart_button']")
		WebElement finishbutton;
		
		@FindBy(xpath="//h2[@class='complete-header']")
		WebElement message;
		
		
		public CheckOutPage()
		{
			PageFactory.initElements(driver, this);	
		}
		public String validateCheckOutPageTitle()
		{
			driver.get(prop.getProperty("url2"));
			Assert.assertEquals(driver.getTitle(),"Swag Labs");
			return driver.getTitle();
		}
		public void CheckOutDetails()
		{
			firstname.sendKeys("FirstName");
			lastname.sendKeys("LastName");
			zipcode.sendKeys("700156");
			continuebutton.click();
			finishbutton.click();
			
		}
		public String validateMessage() {
			Assert.assertEquals(message.getText(),"THANK YOU FOR YOUR ORDER");
			return message.getText();
		}

}
