package assignment2.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;


import assignment.base.TestBase;

public class LoginPageShopingSite extends TestBase{
	
//Page Factory
	
	@FindBy(id="user-name")
	WebElement username;
	
	@FindBy(id="password")
	WebElement password;

	@FindBy(xpath="//input[@value='LOGIN']")
	WebElement login;
	
	public LoginPageShopingSite()
	{
		PageFactory.initElements(driver, this);	
	}
	public String validateLoginPageShopingSiteTitle()
	{
		driver.get(prop.getProperty("url2"));
		Assert.assertEquals(driver.getTitle(),"Swag Labs");
		return driver.getTitle();
	}
	public HomePageShopingSite login()
	{
		username.sendKeys(prop.getProperty("username2"));
		password.sendKeys(prop.getProperty("password2"));
		login.click();
		return new HomePageShopingSite();
	}

}
